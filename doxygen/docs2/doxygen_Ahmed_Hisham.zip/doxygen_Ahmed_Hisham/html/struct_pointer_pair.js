var struct_pointer_pair =
[
    [ "pointer", "struct_pointer_pair.html#ae6067d740982f25ff3cbd5ca68f0b0aa", null ],
    [ "old_value", "struct_pointer_pair.html#a22eefe5979d9ff822eccf52dc57be1e8", null ]
];