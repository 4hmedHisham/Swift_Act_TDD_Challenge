var fake__switches_8c =
[
    [ "get_duration", "fake__switches_8c.html#a94d138d6af47a4a43fd0f047c0e94aad", null ],
    [ "set_duration", "fake__switches_8c.html#a85b958281377fe51c83b9ead1ce23ea8", null ],
    [ "FAKE_SW_init", "fake__switches_8c.html#ac2822f6df5fba90c6ab0a7f92071dcae", null ],
    [ "FAKE_SW_getSwState", "fake__switches_8c.html#a6f1acae2d9ffe896064c712b0bbb7dc6", null ],
    [ "FAKE_SW_setSwState", "fake__switches_8c.html#a748d94e1513505205256e38d3a72a43d", null ],
    [ "SWITCH_getSwState", "fake__switches_8c.html#a912e81d473a062a515a2bb480c95f18f", null ],
    [ "SWITCH_setSwState", "fake__switches_8c.html#a758d87e6530a781e250fd66ca767491d", null ],
    [ "SWITCH_init", "fake__switches_8c.html#adb84ddf5758e565069fa1d6b134522bd", null ]
];