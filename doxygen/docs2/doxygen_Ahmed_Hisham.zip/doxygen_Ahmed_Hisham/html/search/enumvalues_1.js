var searchData=
[
  ['neg_1017',['neg',['../switches_8h.html#a41273fdeb63230b3a5c360d8c7c11b82a6e2d060111a711f5536aee454a4386d2',1,'switches.h']]]
];
