var searchData=
[
  ['p_5fswitch_5finit_889',['p_SWITCH_init',['../switches_8h.html#aaebd96426c2a343cdff292f1ff32cbc8',1,'p_SWITCH_init(void):&#160;swtiches.c'],['../swtiches_8c.html#a89b12623deae9ab3b44cb107aec6bfc5',1,'p_SWITCH_init():&#160;swtiches.c']]],
  ['pos_5fswitch_5finit_890',['pos_SWITCH_init',['../switches_8h.html#abb175273ffbcf235f1542032b14cda4c',1,'pos_SWITCH_init(void):&#160;swtiches.c'],['../swtiches_8c.html#a7af5ee0aebc5255650b671a5eaa4f5f5',1,'pos_SWITCH_init():&#160;swtiches.c']]]
];
