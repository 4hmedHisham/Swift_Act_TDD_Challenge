var searchData=
[
  ['neg_5fswitch_5finit_888',['neg_SWITCH_init',['../switches_8h.html#a6a276dde10d161df96968690b9805064',1,'neg_SWITCH_init(void):&#160;swtiches.c'],['../swtiches_8c.html#aa965b7d4b27cdc9ca633d5c745d7d5b0',1,'neg_SWITCH_init():&#160;swtiches.c']]]
];
