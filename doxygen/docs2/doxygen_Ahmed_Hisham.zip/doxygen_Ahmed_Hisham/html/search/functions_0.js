var searchData=
[
  ['fake_5fsw_5fgetswstate_881',['FAKE_SW_getSwState',['../fake__switches_8c.html#a6f1acae2d9ffe896064c712b0bbb7dc6',1,'FAKE_SW_getSwState(SWITCH_TYPE sw):&#160;fake_switches.c'],['../fake__switches_8h.html#a6f1acae2d9ffe896064c712b0bbb7dc6',1,'FAKE_SW_getSwState(SWITCH_TYPE sw):&#160;fake_switches.c']]],
  ['fake_5fsw_5finit_882',['FAKE_SW_init',['../fake__switches_8c.html#ac2822f6df5fba90c6ab0a7f92071dcae',1,'FAKE_SW_init(void):&#160;fake_switches.c'],['../fake__switches_8h.html#ac2822f6df5fba90c6ab0a7f92071dcae',1,'FAKE_SW_init(void):&#160;fake_switches.c']]],
  ['fake_5fsw_5fsetswstate_883',['FAKE_SW_setSwState',['../fake__switches_8c.html#a748d94e1513505205256e38d3a72a43d',1,'FAKE_SW_setSwState(SWITCH_TYPE type, SWITCH_STATE_t state):&#160;fake_switches.c'],['../fake__switches_8h.html#a748d94e1513505205256e38d3a72a43d',1,'FAKE_SW_setSwState(SWITCH_TYPE type, SWITCH_STATE_t state):&#160;fake_switches.c']]]
];
