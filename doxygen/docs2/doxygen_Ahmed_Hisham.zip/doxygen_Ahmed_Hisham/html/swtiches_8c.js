var swtiches_8c =
[
    [ "pos_SWITCH_init", "swtiches_8c.html#a7af5ee0aebc5255650b671a5eaa4f5f5", null ],
    [ "neg_SWITCH_init", "swtiches_8c.html#aa965b7d4b27cdc9ca633d5c745d7d5b0", null ],
    [ "p_SWITCH_init", "swtiches_8c.html#a89b12623deae9ab3b44cb107aec6bfc5", null ],
    [ "switchesInit", "swtiches_8c.html#adab0ff9bb724ea375fc1d2ce2a8ab4ee", null ],
    [ "GET_REAL_SWITCH_STATE", "swtiches_8c.html#a837108b0b6125654c9869382dfbd30b7", null ],
    [ "Set_REAL_SWITCH_STATE", "swtiches_8c.html#a8c3c5f39d7a7ff140cb371060ec216ae", null ],
    [ "SWITCH_getSwState", "swtiches_8c.html#a912e81d473a062a515a2bb480c95f18f", null ],
    [ "SWITCH_setSwState", "swtiches_8c.html#a758d87e6530a781e250fd66ca767491d", null ],
    [ "SWITCH_init", "swtiches_8c.html#adb84ddf5758e565069fa1d6b134522bd", null ]
];