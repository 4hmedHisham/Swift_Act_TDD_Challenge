var speed__control_8h =
[
    [ "Speed_State", "speed__control_8h.html#ac6b17baf47f40c59c9ad3e6dfc28d819", [
      [ "minimum", "speed__control_8h.html#ac6b17baf47f40c59c9ad3e6dfc28d819a27d4abc2ee7fbee750e9dbef16e5ad9a", null ],
      [ "medium", "speed__control_8h.html#ac6b17baf47f40c59c9ad3e6dfc28d819ae28dc453a60126745c1644b58f32f83c", null ],
      [ "maximum", "speed__control_8h.html#ac6b17baf47f40c59c9ad3e6dfc28d819ac5da3dad4a0eaadeba8544a3f99d718d", null ]
    ] ],
    [ "speed_init", "speed__control_8h.html#aa325d3fcef11c683f859136413abf6df", null ],
    [ "get_speed", "speed__control_8h.html#ab0c22f0e04414a71f48209cdb1b0ccc9", null ],
    [ "set_speed", "speed__control_8h.html#a37b5428158dc44adee45e69f0afb305d", null ],
    [ "update", "speed__control_8h.html#a7ebd9759b4e3197bf52bab531982c0ff", null ]
];