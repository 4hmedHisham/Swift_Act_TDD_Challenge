var struct_u_n_i_t_y___s_t_o_r_a_g_e___t =
[
    [ "TestFile", "struct_u_n_i_t_y___s_t_o_r_a_g_e___t.html#a190c9e7550689c6dceedff539e650336", null ],
    [ "CurrentTestName", "struct_u_n_i_t_y___s_t_o_r_a_g_e___t.html#a6779e1e7dc5d26835d5ca7009242e77c", null ],
    [ "CurrentDetail1", "struct_u_n_i_t_y___s_t_o_r_a_g_e___t.html#a83cef77fb47897cfe6c4dba18d9f36c0", null ],
    [ "CurrentDetail2", "struct_u_n_i_t_y___s_t_o_r_a_g_e___t.html#a46f31dad8da75fe0c1ece891fbb3208b", null ],
    [ "CurrentTestLineNumber", "struct_u_n_i_t_y___s_t_o_r_a_g_e___t.html#af263a120c12a489e9310ef9f36444128", null ],
    [ "NumberOfTests", "struct_u_n_i_t_y___s_t_o_r_a_g_e___t.html#a82127e77cd34e1a1c2b0281e3597d5ba", null ],
    [ "TestFailures", "struct_u_n_i_t_y___s_t_o_r_a_g_e___t.html#a09833b8f72da6d7982f37ebc33111252", null ],
    [ "TestIgnores", "struct_u_n_i_t_y___s_t_o_r_a_g_e___t.html#a4fd439067fb0c1a82a5219077a513cda", null ],
    [ "CurrentTestFailed", "struct_u_n_i_t_y___s_t_o_r_a_g_e___t.html#a60446b592f7989b0f639da4132032a43", null ],
    [ "CurrentTestIgnored", "struct_u_n_i_t_y___s_t_o_r_a_g_e___t.html#ad69a0f6ea7ca97f43b963c8218eca9d6", null ],
    [ "AbortFrame", "struct_u_n_i_t_y___s_t_o_r_a_g_e___t.html#add1ad6305e99da2ddf841e32dfbd8bd5", null ]
];