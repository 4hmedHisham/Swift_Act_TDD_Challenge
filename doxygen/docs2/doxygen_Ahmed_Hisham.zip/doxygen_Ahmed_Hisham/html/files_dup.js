var files_dup =
[
    [ "fake_switches.c", "fake__switches_8c.html", "fake__switches_8c" ],
    [ "fake_switches.h", "fake__switches_8h.html", "fake__switches_8h" ],
    [ "main.c", "main_8c.html", "main_8c" ],
    [ "something.c", "something_8c.html", null ],
    [ "speed_control.c", "speed__control_8c.html", "speed__control_8c" ],
    [ "speed_control.h", "speed__control_8h.html", "speed__control_8h" ],
    [ "speed_control_test.c", "speed__control__test_8c.html", "speed__control__test_8c" ],
    [ "switch_test.c", "switch__test_8c.html", "switch__test_8c" ],
    [ "switches.h", "switches_8h.html", "switches_8h" ],
    [ "swtiches.c", "swtiches_8c.html", "swtiches_8c" ],
    [ "unity.c", "unity_8c.html", "unity_8c" ],
    [ "unity.h", "unity_8h.html", "unity_8h" ],
    [ "unity_fixture.c", "unity__fixture_8c.html", "unity__fixture_8c" ],
    [ "unity_fixture.h", "unity__fixture_8h.html", "unity__fixture_8h" ],
    [ "unity_fixture_internals.h", "unity__fixture__internals_8h.html", "unity__fixture__internals_8h" ],
    [ "unity_internals.h", "unity__internals_8h.html", "unity__internals_8h" ],
    [ "unity_memory.c", "unity__memory_8c.html", "unity__memory_8c" ],
    [ "unity_memory.h", "unity__memory_8h.html", "unity__memory_8h" ]
];