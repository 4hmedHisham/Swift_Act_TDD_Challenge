var unity__memory_8c =
[
    [ "GuardBytes", "struct_guard_bytes.html", "struct_guard_bytes" ],
    [ "MALLOC_DONT_FAIL", "unity__memory_8c.html#a3f1b1eff9064dbe426821f93e435fee5", null ],
    [ "UNITY_MALLOC_ALIGNMENT", "unity__memory_8c.html#a9b85a19cfab2e8492f7e5a41035b4e86", null ],
    [ "Guard", "unity__memory_8c.html#a6f4162ac543f92892987e4557edd1f0b", null ],
    [ "UnityMalloc_StartTest", "unity__memory_8c.html#ad5bf2e255600eb6aef54f95c9a838628", null ],
    [ "UnityMalloc_EndTest", "unity__memory_8c.html#a44409b47989dd823f395d62ba759032a", null ],
    [ "UnityMalloc_MakeMallocFailAfterCount", "unity__memory_8c.html#a987522fae9a5f45af2cf385a2223bdac", null ],
    [ "unity_malloc", "unity__memory_8c.html#a93ff6fda0f975eb47b8d828bd084f411", null ],
    [ "unity_free", "unity__memory_8c.html#a34d61a21a177a63f9681e1d89653cc74", null ],
    [ "unity_calloc", "unity__memory_8c.html#a55e86effa9aaf4a111d6b47684a05369", null ],
    [ "unity_realloc", "unity__memory_8c.html#a943255616637b00dbcf8e798acf0ab20", null ]
];