var fake__switches_8h =
[
    [ "FAKE_SW_getSwState", "fake__switches_8h.html#a6f1acae2d9ffe896064c712b0bbb7dc6", null ],
    [ "FAKE_SW_init", "fake__switches_8h.html#ac2822f6df5fba90c6ab0a7f92071dcae", null ],
    [ "FAKE_SW_setSwState", "fake__switches_8h.html#a748d94e1513505205256e38d3a72a43d", null ],
    [ "get_duration", "fake__switches_8h.html#a94d138d6af47a4a43fd0f047c0e94aad", null ],
    [ "set_duration", "fake__switches_8h.html#a74cac865b66b9100b6d063f11bd7a779", null ]
];