var switches_8h =
[
    [ "SWITCH_STATE_t", "switches_8h.html#add2c37d13e3ac54d516471310b237ac7", [
      [ "SW_PRESSED", "switches_8h.html#add2c37d13e3ac54d516471310b237ac7ae07e75c91d96406b9a19d47ac31518e9", null ],
      [ "SW_RELEASED", "switches_8h.html#add2c37d13e3ac54d516471310b237ac7aa6ecace857f42b47cc7d19d25087caf3", null ],
      [ "SW_PRE_RELEASED", "switches_8h.html#add2c37d13e3ac54d516471310b237ac7acec9a303122b07b05c04bc8c8edcbb67", null ],
      [ "SW_PRE_PRESSED", "switches_8h.html#add2c37d13e3ac54d516471310b237ac7a5356b3d4a45e0dd039e547d132079467", null ]
    ] ],
    [ "SWITCH_TYPE", "switches_8h.html#a41273fdeb63230b3a5c360d8c7c11b82", [
      [ "pos", "switches_8h.html#a41273fdeb63230b3a5c360d8c7c11b82a6fcf6a44eeee46cc0e15d6f0300da3c8", null ],
      [ "neg", "switches_8h.html#a41273fdeb63230b3a5c360d8c7c11b82a6e2d060111a711f5536aee454a4386d2", null ],
      [ "p", "switches_8h.html#a41273fdeb63230b3a5c360d8c7c11b82a188032b3e6837794e08d485d4426f1bb", null ]
    ] ],
    [ "pos_SWITCH_init", "switches_8h.html#abb175273ffbcf235f1542032b14cda4c", null ],
    [ "neg_SWITCH_init", "switches_8h.html#a6a276dde10d161df96968690b9805064", null ],
    [ "p_SWITCH_init", "switches_8h.html#aaebd96426c2a343cdff292f1ff32cbc8", null ],
    [ "Set_REAL_SWITCH_STATE", "switches_8h.html#a2df2c2bf401b136b98c90b3874c4740b", null ],
    [ "GET_REAL_SWITCH_STATE", "switches_8h.html#a16019f85a47fa0c54e1d861c1e5d8d87", null ],
    [ "SWITCH_getSwState", "switches_8h.html#a912e81d473a062a515a2bb480c95f18f", null ],
    [ "SWITCH_setSwState", "switches_8h.html#a758d87e6530a781e250fd66ca767491d", null ],
    [ "SWITCH_init", "switches_8h.html#adb84ddf5758e565069fa1d6b134522bd", null ]
];