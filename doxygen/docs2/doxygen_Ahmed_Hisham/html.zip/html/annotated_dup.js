var annotated_dup =
[
    [ "Text file format:", "index.html#autotoc_md0", [
      [ "The text file is designed to take 3 sequential events to simulate a test case with them, each line coressponds to a a certain amount of ticks depends on the time in ms written", "index.html#autotoc_md1", null ],
      [ "Each 3-sequntial events are separated by a carridge return, below is an explaination to the State machine used in the project and the tree leafs represent the number of testcases, and the depth of the tree represent the number of sequential moves needed to make each test case.", "index.html#autotoc_md2", null ]
    ] ],
    [ "This is an image for the state machine.", "index.html#autotoc_md3", null ],
    [ "This is the 1-Switch State Coverage Tree", "index.html#autotoc_md4", null ],
    [ "GuardBytes", "struct_guard_bytes.html", "struct_guard_bytes" ],
    [ "PointerPair", "struct_pointer_pair.html", "struct_pointer_pair" ],
    [ "UNITY_FIXTURE_T", "struct_u_n_i_t_y___f_i_x_t_u_r_e___t.html", "struct_u_n_i_t_y___f_i_x_t_u_r_e___t" ],
    [ "UNITY_STORAGE_T", "struct_u_n_i_t_y___s_t_o_r_a_g_e___t.html", "struct_u_n_i_t_y___s_t_o_r_a_g_e___t" ]
];