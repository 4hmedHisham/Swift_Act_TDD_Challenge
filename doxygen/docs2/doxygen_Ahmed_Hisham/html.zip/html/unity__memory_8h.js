var unity__memory_8h =
[
    [ "UNITY_MALLOC", "unity__memory_8h.html#ae0db9025d86a0c2d0e4872d6f0da394c", null ],
    [ "UNITY_FREE", "unity__memory_8h.html#aa330d623eb8aea63f867ed9515e44878", null ],
    [ "malloc", "unity__memory_8h.html#acf143577800376dd931c059ecc61ba06", null ],
    [ "calloc", "unity__memory_8h.html#a84beef8cc122add35118ec7cd35286c4", null ],
    [ "realloc", "unity__memory_8h.html#a1b739878adcdb46fb5d209af7ce79628", null ],
    [ "free", "unity__memory_8h.html#a2c6efa7679f8cd9f61af96e105017560", null ],
    [ "unity_malloc", "unity__memory_8h.html#a93ff6fda0f975eb47b8d828bd084f411", null ],
    [ "unity_calloc", "unity__memory_8h.html#a55e86effa9aaf4a111d6b47684a05369", null ],
    [ "unity_realloc", "unity__memory_8h.html#a943255616637b00dbcf8e798acf0ab20", null ],
    [ "unity_free", "unity__memory_8h.html#a34d61a21a177a63f9681e1d89653cc74", null ],
    [ "UnityMalloc_StartTest", "unity__memory_8h.html#ad5bf2e255600eb6aef54f95c9a838628", null ],
    [ "UnityMalloc_EndTest", "unity__memory_8h.html#a44409b47989dd823f395d62ba759032a", null ],
    [ "UnityMalloc_MakeMallocFailAfterCount", "unity__memory_8h.html#a987522fae9a5f45af2cf385a2223bdac", null ]
];