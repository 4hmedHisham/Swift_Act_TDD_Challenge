var speed__control_8c =
[
    [ "get_speed", "speed__control_8c.html#a9a6ff610ea9c0e09854e5d97eb7bdd65", null ],
    [ "set_speed", "speed__control_8c.html#a37b5428158dc44adee45e69f0afb305d", null ],
    [ "speed_init", "speed__control_8c.html#a5c182a96c509bd50c298a218c7af05f6", null ],
    [ "update", "speed__control_8c.html#ac5c54df7ed3b930268c8d7752c101725", null ]
];