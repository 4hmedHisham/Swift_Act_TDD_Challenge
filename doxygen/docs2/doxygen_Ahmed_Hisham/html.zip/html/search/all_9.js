var searchData=
[
  ['old_5fvalue_44',['old_value',['../struct_pointer_pair.html#a22eefe5979d9ff822eccf52dc57be1e8',1,'PointerPair']]]
];
