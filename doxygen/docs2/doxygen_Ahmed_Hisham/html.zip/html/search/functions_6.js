var searchData=
[
  ['sequence_5fimplementer_893',['sequence_implementer',['../speed__control__test_8c.html#a429d640f41690f61d3f557b048937cdd',1,'speed_control_test.c']]],
  ['set_5fduration_894',['set_duration',['../fake__switches_8c.html#a85b958281377fe51c83b9ead1ce23ea8',1,'set_duration(int duration):&#160;fake_switches.c'],['../fake__switches_8h.html#a74cac865b66b9100b6d063f11bd7a779',1,'set_duration(int):&#160;fake_switches.c']]],
  ['set_5freal_5fswitch_5fstate_895',['Set_REAL_SWITCH_STATE',['../switches_8h.html#a2df2c2bf401b136b98c90b3874c4740b',1,'Set_REAL_SWITCH_STATE(SWITCH_TYPE SW_TYPE, SWITCH_STATE_t state):&#160;swtiches.c'],['../swtiches_8c.html#a8c3c5f39d7a7ff140cb371060ec216ae',1,'Set_REAL_SWITCH_STATE(SWITCH_TYPE type, SWITCH_STATE_t state):&#160;swtiches.c']]],
  ['set_5fspeed_896',['set_speed',['../speed__control_8c.html#a37b5428158dc44adee45e69f0afb305d',1,'set_speed(Speed_State speed):&#160;speed_control.c'],['../speed__control_8h.html#a37b5428158dc44adee45e69f0afb305d',1,'set_speed(Speed_State speed):&#160;speed_control.c']]],
  ['setup_897',['setUp',['../unity_8h.html#a95c834d6178047ce9e1bce7cbfea2836',1,'setUp(void):&#160;unity_fixture.c'],['../unity__fixture_8c.html#a95c834d6178047ce9e1bce7cbfea2836',1,'setUp(void):&#160;unity_fixture.c']]],
  ['speed_5finit_898',['speed_init',['../speed__control_8c.html#a5c182a96c509bd50c298a218c7af05f6',1,'speed_init():&#160;speed_control.c'],['../speed__control_8h.html#aa325d3fcef11c683f859136413abf6df',1,'speed_init(void):&#160;speed_control.c']]],
  ['suitesetup_899',['suiteSetUp',['../unity_8h.html#a0f08bc53b5978d3892a36f98df005b37',1,'unity.h']]],
  ['suiteteardown_900',['suiteTearDown',['../unity_8h.html#a3eac1f0f22f9093d82efeed457a1b1d3',1,'unity.h']]],
  ['switchesinit_901',['switchesInit',['../swtiches_8c.html#adab0ff9bb724ea375fc1d2ce2a8ab4ee',1,'swtiches.c']]]
];
