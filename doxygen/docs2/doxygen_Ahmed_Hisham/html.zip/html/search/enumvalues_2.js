var searchData=
[
  ['p_1018',['p',['../switches_8h.html#a41273fdeb63230b3a5c360d8c7c11b82a188032b3e6837794e08d485d4426f1bb',1,'switches.h']]],
  ['pos_1019',['pos',['../switches_8h.html#a41273fdeb63230b3a5c360d8c7c11b82a6fcf6a44eeee46cc0e15d6f0300da3c8',1,'switches.h']]]
];
