var searchData=
[
  ['speed_5fstate_1007',['Speed_State',['../speed__control_8h.html#ac6b17baf47f40c59c9ad3e6dfc28d819',1,'speed_control.h']]],
  ['switch_5fstate_5ft_1008',['SWITCH_STATE_t',['../switches_8h.html#add2c37d13e3ac54d516471310b237ac7',1,'switches.h']]],
  ['switch_5ftype_1009',['SWITCH_TYPE',['../switches_8h.html#a41273fdeb63230b3a5c360d8c7c11b82',1,'switches.h']]]
];
