var searchData=
[
  ['pointerpair_859',['PointerPair',['../struct_pointer_pair.html',1,'']]]
];
