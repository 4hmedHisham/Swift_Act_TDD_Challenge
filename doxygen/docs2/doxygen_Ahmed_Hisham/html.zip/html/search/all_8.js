var searchData=
[
  ['namefilter_40',['NameFilter',['../struct_u_n_i_t_y___f_i_x_t_u_r_e___t.html#a05d7df20a22a79f03f4b94e97fe9485e',1,'UNITY_FIXTURE_T']]],
  ['neg_41',['neg',['../switches_8h.html#a41273fdeb63230b3a5c360d8c7c11b82a6e2d060111a711f5536aee454a4386d2',1,'switches.h']]],
  ['neg_5fswitch_5finit_42',['neg_SWITCH_init',['../switches_8h.html#a6a276dde10d161df96968690b9805064',1,'neg_SWITCH_init(void):&#160;swtiches.c'],['../swtiches_8c.html#aa965b7d4b27cdc9ca633d5c745d7d5b0',1,'neg_SWITCH_init():&#160;swtiches.c']]],
  ['numberoftests_43',['NumberOfTests',['../struct_u_n_i_t_y___s_t_o_r_a_g_e___t.html#a82127e77cd34e1a1c2b0281e3597d5ba',1,'UNITY_STORAGE_T']]]
];
