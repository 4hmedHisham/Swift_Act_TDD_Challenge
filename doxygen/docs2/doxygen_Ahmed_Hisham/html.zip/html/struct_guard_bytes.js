var struct_guard_bytes =
[
    [ "size", "struct_guard_bytes.html#a854352f53b148adc24983a58a1866d66", null ],
    [ "guard_space", "struct_guard_bytes.html#ab6abac3ecaf24678de12c2eee28ac139", null ]
];